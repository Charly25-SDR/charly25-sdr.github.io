killall sdr-transceiver-hpsdr
