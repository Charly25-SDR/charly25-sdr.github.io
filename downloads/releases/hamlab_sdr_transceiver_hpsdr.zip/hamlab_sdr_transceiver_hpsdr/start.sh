hamrf -s
gpiorelay -s

/opt/redpitaya/www/apps/hamlab_sdr_transceiver_hpsdr/sdr-transceiver-hpsdr &
