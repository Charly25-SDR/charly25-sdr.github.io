killall sdr-transceiver-hpsdr

hamrf -i
gpiorelay -i

